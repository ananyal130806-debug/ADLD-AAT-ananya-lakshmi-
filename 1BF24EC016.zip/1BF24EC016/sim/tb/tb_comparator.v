`timescale 1ns/1ps
module comparator_4bit_tb;
    reg  [3:0] a, b;
    wire       gt, eq, lt;

    // cascade inputs tied off for stand-alone use
    comparator_4bit uut (.a(a), .b(b), .gt_in(1'b0), .eq_in(1'b1), .lt_in(1'b0),
                         .gt(gt), .eq(eq), .lt(lt));

    initial begin
        $dumpfile("dump.vcd");
        $dumpvars(0, comparator_4bit_tb);
        $monitor("t=%0d ns  a=%0d b=%0d  ->  gt=%b eq=%b lt=%b", $time, a, b, gt, eq, lt);
        a = 4'd5;  b = 4'd3;   #10;
        a = 4'd3;  b = 4'd5;   #10;
        a = 4'd7;  b = 4'd7;   #10;
        a = 4'd8;  b = 4'd7;   #10;
        a = 4'd0;  b = 4'd15;  #10;
        a = 4'd15; b = 4'd15;  #10;
        $finish;
    end
endmodule
