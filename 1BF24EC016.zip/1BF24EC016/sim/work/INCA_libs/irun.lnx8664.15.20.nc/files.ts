1793255663 /home/student/cds.lib
1793274235 /home/student/cadWorkDir/myProjects/Digital/1BF24EC016/sim/rtl/comparator.v
1793274342 /home/student/cadWorkDir/myProjects/Digital/1BF24EC016/sim/tb/tb_comparator.v
