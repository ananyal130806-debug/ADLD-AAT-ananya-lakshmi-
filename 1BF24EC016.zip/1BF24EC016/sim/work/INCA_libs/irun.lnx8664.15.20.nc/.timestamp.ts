1793274342 /home/student/cadWorkDir/myProjects/Digital/1BF24EC016/sim/tb/tb_comparator.v
1793274235 /home/student/cadWorkDir/myProjects/Digital/1BF24EC016/sim/rtl/comparator.v
